<!-- Header Area  -->
<?php
include("asset/header.php");
?>


<!------slider----->
<?php
include("asset/slider.php");
?>

<!-----Team Area ---->
<div class="team">
	<div class="row team1">
		<div class="col-md-1"></div>
		<div class="col-md-6">
			<u>
				<h5>Regional Rapid Response Team</h5>
			</u>
			<ul>
				<li>Regional Rapid Response Team (Kholna Regional)</li>
				<li>Regional Rapid Response Team (Chattogram Regional)</li>
				<li>Regional Rapid Response Team (Shylhet Regional)</l>

			</ul>
		</div>
		<div class="col-md-5">
			<br>
			<p>Discluser on Risks Based Capital(Base)</p>
			<p>Cautionary Notice: Positive Pay Instruction </p>
			<br>
		</div>
	</div>
</div>

<!-----//Team Area ---->

<!--Brand Area -->
<?php
include("asset/brand.php")
?>
<!--//Brand Area-->
<!------TABLE Area   ----->
<?php
include("asset/table.php");
?>
<!--//Table Area-->

<!--bottom pic-->
<div class="container-flex">
	<div class="bottom_pic">
		<div class="row">
			<div class="col-md-6">
				<br>
				<br>
				<h2>Tell Us How We can Be Better </h2>
				<h4>Your Mail Address(Optional):<h4>
			</div>
			<div class="col-md-6">
				<form action="" name="">
					<div class="form-group">
						<label for="email">EMAIL:</label>
						<input type="email" name="email" class="form-control" id="email" placeholder="Submit your Email" required>
						<label for="email">COMMENT:</label>
						<textarea type="text" name="comment" class="form-control" placeholder="Please Enter Your Comment" required></textarea>
						<br>
						<button type="submit" name="submit" class="btn btn-danger text-align-right">Send Please<button>
				</form>
			</div>
		</div>

	</div>
</div>
<!--//bottom pic-->

<!-- footer start -->
<?php
include('asset/footer.php');
?>