<div class="table_area">

    <div class="row table_area1">
        <div class="col-md-4">
            <table class="table table-striped">
                <tr style="background-color:#DC3545; color:white;">
                    <td colspan="2">Exchanges Rates</td>
                    <td>20/12/2020 >></td>
                </tr>
                <tr>
                    <th>CURRENCY</th>
                    <th>TT BUY</th>
                    <th>TT SELL</th>

                </tr>
                <tr>
                    <td>USD</td>
                    <td>94.984</td>
                    <td>94.984</td>
                </tr>
                <tr>
                    <td>EUR</td>
                    <td>118.748</td>
                    <td>118.748</td>
                </tr>
                <tr>
                    <td>GBP</td>
                    <td>120.455</td>
                    <td>120.455</td>
                </tr>
            </table>
            <br>

            <table class="table table-striped">
                <tr style="background-color: #DC3545; color:white;">
                    <td colspan="2">DA Share Price</td>
                    <td>20/12/2020 >></td>
                </tr>
                <tr>
                    <th>EXCHANGE </th>
                    <th>OPEN*</th>
                    <th>CLOSE</th>

                </tr>
                <tr>
                    <td>DSE</td>
                    <td>10.30</td>
                    <td>12.30</td>
                </tr>
                <tr>
                    <td>CSE</td>
                    <td>10.30</td>
                    <td>12.30</td>
                </tr>

            </table>
        </div>
        <div class="col-md-4">
            <h3>Recent News</h3>
            <h5>Mr. Shafiqul Alam appinted</h5>
            <p>Mr.Shafiqul Alam joined AB Bank as Independent Director With effect from September 7, 2020 Mr. Alam, a seasoned banker...</p>
            <h5 style="text-align:right;">September 10,2020</h5>
            <h4>Mr. Shafiqul Alam appointed</h4>
            <p>Mr.Shafiqul Alam joined AB Bank as Independent Director With effect from September 7, 2020 Mr. Alam, a seasoned banker...</p>
            <h5 style="text-align:right;">September 10,2020</h5>
            <h4>Mr. Shafiqul Alam appointed</h4>
            <p>Mr.Shafiqul Alam joined AB Bank as Independent Director With effect from September 7, 2020 Mr. Alam, a seasoned banker...</p>
            <h5 style="text-align:right;">September 10,2020</h5>
        </div>
        <div class="col-md-4">

            <!-- <span class="ab-button-icon"><i class="fa fa-bar-chart"></i></span>
							সেবার হার এবং মূল্য <span class="ab-button-chevron"><i class="fa fa-chevron-right">
							</i></span>
							<i class="fa fa-bar-chart"></i> -->




            <div class="card bg-danger text-white">
                <div class="card-body">RATES 7 CHARGES</div>
            </div>
            <br>
            <div class="card bg-danger text-white">
                <div class="card-body">REPORTS</div>
            </div>
            <br>
            <div class="card bg-danger text-white">
                <div class="card-body">FIND BRANCH& ATM</div>
            </div>
            <br>
            <div class="card bg-danger text-white">
                <div class="card-body">PRICE SENSITIVE INFORMATION</div>
            </div>
            <br>
            <div class="card bg-danger text-white">
                <div class="card-body">UNCLAMED DEPOSITS INFORMATION</div>

            </div>
            <br>
            <div class="card bg-danger text-white">
                <div class="card-body">DOWNLOAD FORMS </div>
            </div>

        </div>
    </div>

</div>