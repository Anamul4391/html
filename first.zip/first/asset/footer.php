<div class="container-flex">
    <div class="footer">
        <div class="row">
            <div class="col-md-1"></div>
            <div class="col-md-3 align-right">
                <h4>Information</h4>
                <p>Background of Discount Ache</p>
                <p>Corporate Information</p>
                <p>visison & Mision</p>
            </div>
            <div class="col-md-2">
                <h4>Retail Service</h4>
                <p>Educational</p>
                <p>SME Service</p>
                <p>FAQ for SMS</p>
            </div>
            <div class="col-md-2">
                <h4>service</h4>
                <p>Various Service</p>
                <p>SME Service</p>
                <p>FAQ for SMS</p>
            </div>
            <div class="col-md-3">
                <p> <a href="#"><i class="fas fa-search-location"></i></a> 4th floar, House-12, Mothi Complex,
                    chack Bazar, chattogram</p>
                <p><a href="#"><i class="fas fa-phone"></i></a> 01514212121, 01254252525</p>
                <p><a href="#"><i class="fas fa-envelope-open"></i></a> example@gmail.com</p>
                <p><a href="#"><i class="fab fa-firefox"></i></a> www.discountache.com</p>
            </div>
            <div class="col-md-1"></div>
        </div>
    </div>
</div>
<!-- footer end -->
<!-- footer start -->
</div>
</body>

</html>