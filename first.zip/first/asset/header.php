<!DOCTYPE html>
<html>

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
    <link rel="stylesheet" type="text/css" href="style.css">
    <link rel="stylesheet" href="css/bootstrap.min.css">
    <script src="https://code.jquery.com/jquery-3.2.1.slim.min.js" integrity="sha384-KJ3o2DKtIkvYIK3UENzmM7KCkRr/rE9/Qpg6aAZGJwFDMVNA/GpGFF93hXpG5KkN" crossorigin="anonymous"></script>

    <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.5.1/jquery.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.12.9/umd/popper.min.js" integrity="sha384-ApNbgh9B+Y1QKtv3Rn7W3mgPxhU9K/ScQsAP7hUibX39j7fakFPskvXusvfa0b4Q" crossorigin="anonymous"></script>
    <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.0.0/js/bootstrap.min.js" integrity="sha384-JZR6Spejh4U02d8jOt6vLEHfe/JQGiRRSQQxSfFWpi1MquVdAyjUar5+76PVCmYl" crossorigin="anonymous"></script>
    <script src='https://kit.fontawesome.com/a076d05399.js'></script>
</head>

<body>

    <!-- heaer area -->
    <header class="header_area">

        <div class="row top_header m-0">
            <div class="col-md-6 text-center">Complaint Cell |</div>
            <div class="col-md-6 text-right">Bangla | Webmail</div>
        </div>

        <div class="row navbar">
            <div class="col-md-2">
                <a href="#"><img src="photo/logo.jpg" style="width:100px;">
            </div>
            <div class="col-md-10">
                <div class="row">
                    <div class="col-md-8"></div>
                    <div class="col-md-4 text-right">
                        <form class="form d-flex" action="">
                            <input class="form-control mr-sm-2" type="text" placeholder="Search">
                            <button class="btn" type="submit"><i class='fas fa-search'>
                                </i></button>
                        </form>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <nav class="navbar navbar-expand-sm bg-light navbar-light">
                            <!-- Links -->
                            <ul class="navbar-nav">
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn"><a href="./about.php"></a>Home</button>
                                        <div class="dropdown-content"></div>
                                    </div>

                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">About Us</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Background Of ABBL</a>
                                            <a href="./about_vision.php">Vision & Mision</a>
                                            <a href="#">Board Of Director</a>
                                            <a href="#">Senior Management </a>

                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Subsidiaries</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Subsidiaries</a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Cards</button>
                                        <div class="dropdown-content">
                                            <a href="./card.php">Personal Cards</a>
                                            <a href="#">Family Cards</a>
                                            <a href="#">International Cart</a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Hotel</button>
                                        <div class="dropdown-content">
                                            <a href="./hotel.php">Top International Hotel</a>
                                            <a href="#">Top Bangladeshi Hotel</a>
                                            <a href="#">Top Cox-Bazar Hotel</a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Hospital</button>
                                        <div class="dropdown-content">
                                            <a href="./hospital.php">Top International Hospital</a>
                                            <a href="#">Top Bangladeshi Hospital</a>
                                            <a href="#">Top Cox-Bazar Hospital</a>
                                        </div>
                                    </div>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Rates & Charges</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Rates Of ABBL</a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Services</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Services Of ABBL</a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">Investors Relation</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Investors</a>
                                </li>
                                <li>
                                    <div class="dropdown">
                                        <button class="dropbtn">AB Network</button>
                                        <div class="dropdown-content">
                                            <a href="./about.php">Network</a>
                                </li>
                            </ul>
                        </nav>
                    </div>
                </div>
            </div>
        </div>
    </header>