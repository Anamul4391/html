<div class="container brand">
    <h2 class="product"><span style="color:red;">Products</span> & Services</h2>
    <div class="row">
        <div class="col-md-3">
            <img class="rounded" src="photo/logo.jpg">
            <h5>TOP BRAND</h5>
            <ul>
                <li>BATA</li>
                <li>APEX</li>
                <li>AARONG</li>
                <li>CATSEYE</li>
                <li>BROTHER FURNITURE</li>
                <li>FORTUNA</li>
                <li>BNGLADESH</li>

            </ul>
            <a href="#" class="read">Read More</a>
        </div>
        <div class="col-md-3">
            <img class="rounded" src="photo/logo.jpg">
            <h5>REGULAR BRAND</h5>
            <ul>
                <li>SKEHERS</li>
                <li>ITALY FOODWEAR LIMITED</li>
                <li>ZARA</li>
                <li>PARTEX BEVERAGE LTD</li>
                <li>BERGER PAINTS BANGLADESH</li>
                <li>LIMITED</li>
                <li>LEREVE</li>

            </ul>
            <a href="#" class="read">Read More</a>
        </div>
        <div class="col-md-3">
            <img class="rounded" src="photo/logo.jpg">
            <h5>COMMON BRAND</h5>
            <ul>
                <li>Cafe Milano</li>
                <li>The Arrosto</li>
                <li>BIR Chatta</li>
                <li>Red Chilli</li>
                <li>Silver Spooon</li>
                <li>SKEHERS</li>
                <li>Appentito</li>

            </ul>
            <a href="#" class="read">Read More</a>
        </div>
        <div class="col-md-3">
            <img class="rounded" src="photo/logo.jpg">
            <h5>OTHER BRAND</h5>
            <ul>
                <li>BATA</li>
                <li>APEX</li>
                <li>AARONG</li>
                <li>CATSEYE</li>
                <li>BROTHER FURNITURE</li>
                <li>FORTUNA</li>
                <li>BNGLADESH</li>

            </ul>
            <a href="#" class="read">Read More</a>
        </div>
    </div>

</div>