<?php
include("asset/header.php");
?>
<div class="container fluex">
    <div class="visionBanner">
        <div class="row">
            <div class="col-md-3"></div>
            <div class="col-md-9 top">
                <h2>AB Bank</h2>
                <h2>Vision & Mision</h2>
            </div>
        </div>
    </div>
</div>
<?php
include("asset/footer.php");
?>