<?php
include("asset/header.php");
?>
<div class="container-flex about">
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <h2>Background Of "Discount Ache"</h2>
            <p>Introducing Bangladesh to its very first private sector bank; AB Bank Limited was incorporated on 31st December, 1981. Arab Bangladesh Bank as formerly known started its effective operation from 12th April, 1982 with the mission to be the best performing bank of the country.</p>

            <p>
                With an ambition to secure its place as the leading service provider, creating lasting value for its clientele, shareholder, and employees and particularly for the community it operates in, AB has formulated a golden heritage and an envious legacy that may not be imitated by many. Achieving plenty of milestones and incorporating numerous changes over the last 38 years, AB has always been authentic to its desire of being the technology driven innovative bank of Bangladesh. To excel this new era of technological triumph, AB has successfully introduced internet banking, SMS banking, cutting edge ICT, state-of-art network solution, 24/7 ATM service and many other e-products.
            </p>

            <p>
                AB has extensively widened its services over the last three decades in both home and abroad. The bank opened its very first branch at Karwan Bazar on 12th April 1982 and now has a successful footprint of 105 branches including one overseas branch in Mumbai, India and 270 plus ATMs spread across the country. it has associated 5 subsidiary companies including one Off-shore Banking Unit and Custodial services with its core banking activities. The Bank opened its Representative Office at Yangon, Myanmar for extending its foreign operations.
            </p>

        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4"></div>
        <div class="col-md-4">
            <h2>The Rebanding</h2>
            <p>
                AB took a conscious effort to rejuvenate its past identity; that is carried as Arab Bangladesh Bank Limited for 25 long years. Hence it chose to rename itself as AB Bank Limited and Bangladesh Bank put its affirmative stamp on November 14, 2007. The bank’s new logo symbolizes the blend of bonding and trust. It developed its logo with the auspicious of its vision and mission and core values with contemporary theme. The new logo represents our cultural "Sheetal pati" as it reflects the bonding with its clientele and fulfilling their every need. Thus the new spirit of AB is "Bonding".
            </p>

        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row about">
        <div class="col-md-2"></div>
        <div class="col-md-4">
            <h2>Products Galary</h2>
        </div>
        <div class="col-md-4"></div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-4">
            <p>
                Through its wide slew of diversified product and services, now AB has affirmed its position to the top rated banks of the country. AB offers a wide range of depository and loan products to cater virtually for every customer segment. From Student Banking to Priority Banking AB approximately has all banking products in its repertoire. The product gallery is rich in content and innovative products and services are introduced in the field of Small and Medium Enterprise (SME) credit, Women's Entrepreneur, Consumer Loans, Debit and Credit Cards (Local & International), ATMs, Internet and SMS Banking, Remittance Services, Treasury Products and Services, Structured Finance for Corporate, strengthening and expanding its Islamic Banking activities, Investment Banking, specialized products and services for NRBs, Priority Banking, and Customer Care. AB has High quality products and services and dedicated Relationship Managers who are committed to financial health management, preserve lifestyle and maintain priorities of the customers wherever life takes them.
            </p>
        </div>
        <div class="col-md-4">
            <div class="row">
                <div class="col-md-4"></div>
                <div class="col-md-4"> <img src="photo/about/about1.jpg" class="img-thumbnail" style="height:80px; width:90px; margin:2px;"></div>
                <div class="col-md-4"> <img src="photo/about/about2.jpg" class="img-thumbnail" style="height:80px; width:90px;"></div>
            </div>
            <div class="row">
                <div class="col-md-4"> <img src="photo/about/about3.jpg" style="height:80px; width:90px;  margin:2px;"></div>
                <div class="col-md-4"> <img src="photo/about/about4.png" style="height:80px; width:90px;  margin:2px;"></div>
                <div class="col-md-4"> <img src="photo/about/about5.jpg" style="height:80px; width:90px;"></div>
            </div>
            <div class="row">
                <div class="col-md-4"> <img src="photo/about/about1.jpg" style="height:80px; width:90px;  margin:2px;"></div>
                <div class="col-md-4"> <img src="photo/about/about2.jpg" style="height:80px; width:90px;  margin:2px;"></div>
                <div class="col-md-4"></div>
            </div>
        </div>
        <div class="col-md-2"></div>
    </div>
    <div class="row">
        <div class="col-md-2"></div>
        <div class="col-md-8">
            <ul>
                <li>First Private Commercial Bank to start Banking Operation (1982)</li>
                <li>First ATM at Gulshan Club (1996)</li>
                <li>First Teller System in Branches (1982)</li>
                <li>First in syndication Finance to BIMAN (2009)</li>
                <li>First financing in Ship building : Western Marine (2009)</li>
                <li>First in using SWIFT (1999)</li>
                <li>First Multi Bank owned Switching network : CBL (2008)</li>
                <li>First in opening Merchant Banking Wing (2002)</li>
                <li>First to have a Financial House abroad at Hong Kong (1995)</li>
                <li>First to open overseas Branch at Mumbai (1996)</li>
                <li>First subsidiary for Merchant Banking: AB Investment Limited (2009)</li>
                <li>First to have a representative office in Myanmar (2010)</li>
                <li>First to invest in Sri Lanka – Amana Bank Ltd. (2011)</li>

            </ul>
            <p>
                Throughout the journey of excellence, AB Bank has been a genuine care giver in the Health, Education and sports sectors. As Bangladesh’s benchmark bank it has always been at the forefront to assist during critical moments like donating to help the victims of Rana Plaza, standing beside the families affected by BDR Tragedy, distributing warm cloths among the victims of Ramu, contributing to the patients of the devastating Nimtoli fire at old Dhaka etc. Trust and integrity have been the key value components when meeting the expectations of every stakeholder. As such, AB Bank has molded an exceptionally talented team of employees helping them reach their optimum potential. Precisely understanding the needs of customers, the bank has provided new and imaginative schemes that has altogether redefined convenience in financial services and revolutionized the nature of banking in Bangladesh.
            </p>

        </div>
        <div class="col-md-2"></div>
    </div>

</div>
<?php
include("asset/footer.php");
?>