<!--header area -->
<?php
include("asset/header.php");
?>
<!--Bannar Area-->
<div class="container cardImage">
    <img src="photo/card.PNG">
    <h2>AB Bank Card</h2>
    <div class="row">
        <div class="col-md-6 atmCard">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <h4>Debit Card</h4>
                    <p>Some of life’s surprises arise at the most unexpected moments. Treat your AB Bank's Credit Card as your instant source for cash...</p>
                    <h5><i class="fas fa-arrow-alt-circle-right"></i>Read More</h5>
                </div>
            </div>
        </div>
        <div class="col-md-6 atmCard">
            <div class="card bg-secondary text-white">
                <div class="card-body">
                    <h4>Credit Card</h4>
                    <p>Some of life’s surprises arise at the most unexpected moments. Treat your AB Bank's Credit Card as your instant source for cash...</p>
                    <h5><i class="fas fa-arrow-alt-circle-right"></i>Read More</h5>
                </div>
            </div>
        </div>
    </div>
</div>

<!-- footer start -->
<?php
include("asset/footer.php");

?>