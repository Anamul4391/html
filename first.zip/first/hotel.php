<!--header Area -->
<?php
include("asset/header.php");
?>
<!--//Header Area--->


<div class="container">
    <h1 style="text-align:center; padding-top:10px; color:cornflowerblue; font-size:50px; font-weight:bold" ;>Best Luxery Hotels in Bangladesh</h1>
    <!-- <div id="myCarousel" class="carousel slide" data-ride="carousel">
        <ol class="carousel-indicators">
            <li data-target="#myCarousel" data-slide-to="0" class="active"></li>
            <li data-target="#myCarousel" data-slide-to="1"></li>
            <li data-target="#myCarousel" data-slide-to="2"></li>
        </ol>
    </div> -->


    <!-- carousal/slider start -->
    <div class="container">
        <div id="carouselExampleIndicators" class="carousel slide" data-ride="carousel">
            <ol class="carousel-indicators">
                <li data-target="#carouselExampleIndicators" data-slide-to="0" class="active"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="1"></li>
                <li data-target="#carouselExampleIndicators" data-slide-to="2"></li>
            </ol>

            <div class="carousel-inner">
                <div class="carousel-item active">
                    <img class="d-block w-100" src="photo/slider_image/slider1.jpg" alt="First slide">
                    <div class="carousel-caption d-none d-md-block">
                        <h5>My Caption Title (1st Image)</h5>
                        <p>The whole caption will only show up if the screen is at least medium size.</p>
                    </div>
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="photo/slider_image/slider2.jpg" alt="Second slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="photo/slider_image/slider3.jpg" alt="Third slide">
                </div>
                <div class="carousel-item">
                    <img class="d-block w-100" src="photo/slider_image/slider4.jpg" alt="Forth slide">
                </div>
            </div>

            <a class="carousel-control-prev" href="#carouselExampleIndicators" role="button" data-slide="prev">
                <span class="carousel-control-prev-icon" aria-hidden="true"></span>
                <span class="sr-only">Previous</span>
            </a>
            <a class="carousel-control-next" href="#carouselExampleIndicators" role="button" data-slide="next">
                <span class="carousel-control-next-icon" aria-hidden="true"></span>
                <span class="sr-only">Next</span>
            </a>
        </div>
    </div>
    <!-- carousal/slider end -->

    <h2 style="text-align:center; color:cadetblue; font-weight: bold; padding-bottom: 20px; padding-top: 20px">Discover the Best Hotels for getting your discount.</h2>
    <p></p>
</div>

<div class="container hotelimage">

    <div class="row">
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="#">
                <img src="photo/hotelimage/1.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/2.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/3.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/4.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/4.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/5.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/6.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/3.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/7.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/8.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/9.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
        <div class="col-md-3; col-sm-6; col-xs-12">
            <a href="">
                <img src="photo/hotelimage/3.jpg" class="img-thumbnail" alt="">
                <div class="caption" style="text-align:center;">Hotel Shonargaon</div>
            </a>
        </div>
    </div>

    <div class="row">
        <div class="col-md-12;">
            <h3 style="text-align:center; color:cadetblue; text-align: center; font-size:45px; padding:20px">The Top 5 Star Luxury Hotels Compared.</h3>
            <p style="font-size:15px; color:darkgray">Lorem ipsum dolor sit amet consectetur adipisicing elit. Ad asperiores voluptas nemo unde minus facere molestiae hic nihil delectus numquam beatae itaque voluptate praesentium sunt, ducimus debitis aspernatur! Explicabo, unde. Lorem ipsum, dolor sit amet consectetur adipisicing elit. Maxime pariatur mollitia facere nesciunt nulla dicta doloremque numquam ducimus in eius culpa earum porro et officiis sapiente iure, praesentium possimus adipisci.</p>
        </div>
    </div>



</div>

<!-- footer start -->
<?php
include("asset/footer.php");
?>
<!--end footer-->