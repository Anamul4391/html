<!DOCTYPE html>
<html lang="en" ng-app="charity">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Welfare Society</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400%7CSource+Sans+Pro:700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<script src="ngmodules/angular.js"></script>
	<script>
		angular.module("charity", []);
		angular.module("charity")
		.controller("charityCtrl", function ($scope, $http) {
		/* this is for show user */
		$scope.data = {};
		$scope.msg = '';
		
        
		
		/* this is for create user */
        $scope.createUser = function (ud) {
            $http.post('http://localhost/charity/php/createdonation.php',ud)
			.success(function (d) {
				$scope.msg = 'Your donation request has been sent.';
				$scope.data = null;
			});
		}


    });
	</script>
</head>

<body ng-controller="charityCtrl">

	<header>
		<!-- NAVGATION -->
		<nav id="main-navbar">
			<div class="container">
				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a class="logo" href="index.html"><img src="img/logo.png" alt="logo"></a>
					</div>
				<!-- Mobile toggle -->
					<button class="navbar-toggle-btn">
							<i class="fa fa-bars"></i>
						</button>
				
					<!-- Mobile Search toggle -->
					<button class="search-toggle-btn">
							<i class="fa fa-search"></i>
						</button>
				
				</div>

				<!-- Search -->
				<div class="navbar-search">
					<button class="search-btn"><i class="fa fa-search"></i></button>
					<div class="search-form">
						<form>
							<input class="input" type="text" name="search" placeholder="Search">
						</form>
					</div>
				</div>
				
				<!-- Nav menu -->
				<ul class="navbar-menu nav navbar-nav navbar-right">
					<li><a href="index.php">Home</a></li>
					<li><a href="donation.php">Donation-Contact</a></li>
					<li><a href="registration.php">Member Registration</a></li>
				</ul>
			</div>
		</nav>
	</header>
<div class="container" style="padding-top:80px;background:#fff">
	<h2 align="center">Donation form</h2>
	{{ msg }}
		<form class="form-horizontal" method='post'>
  
			<div class="form-group">
			  <label class="control-label col-sm-2" for="email">Name:</label>
			  <div class="col-sm-10">
				<input type="text" class="form-control" id="name" placeholder="Enter your name" ng-model="data.name">
			  </div>
			</div>
			
			<div class="form-group">
			  <label class="control-label col-sm-2" for="email">Mobile:</label>
			  <div class="col-sm-10">
				<input type="text" class="form-control" id="mobile" placeholder="Enter your mobile no" ng-model="data.mobile">
			  </div>
			</div>
			
			 <div class="form-group">
			  <label class="control-label col-sm-2" for="email">Profesion</label>
			  <div class="col-sm-10">
				<input type="text" class="form-control" id="profesion" placeholder="Enter your profesion" ng-model="data.profesion">
			  </div>
			</div>

	
			<div class="form-group">
			  <label class="control-label col-sm-2" for="email">Date: </label>
			  <div class="col-sm-10">
				<input type="date" class="form-control" id="date" placeholder="Enter your birth date" ng-model="data.date">
			  </div>
			</div>
	
			 <div class="form-group">
			  <label class="control-label col-sm-2" for="email">Amount</label>
			  <div class="col-sm-10">
				<input type="text" class="form-control" id="payment" placeholder="Enter your amount" ng-model="data.amount">
			  </div>
			</div>
			 <div class="form-group">        
      <div class="col-sm-offset-2 col-sm-10">
        <button type="submit" ng-click="createUser(data)" class="btn btn-primary">Submit</button>
      </div>
    </div>
		</form>
</div>
</body>
</html>


<?php
class database{
	public $connect;
	public function __construct(){
		$this->connect=new mysqli("localhost","root","","charity");
	}
	public function insert($q){
		$result=$this->connect->query($q);
		return $result;
	}
}
if(isset($_POST['submit'])){
	$db=new database;
	$name=$_POST['name'];
	$mobile=$_POST['mobile'];
	$profesion=$_POST['profesion'];
	$date=$_POST['date'];
	$payment=$_POST['payment'];
	
$query="insert into donation set name='$name', mobile='$mobile',profesion='$profesion', date='$date', payment='$payment'";
$result=$db->insert($query);
if($result){echo "<h2>Registration Successfull</h2>";}else{
	echo "<h2>Registration Not Complited</h2>";
}
}
?>