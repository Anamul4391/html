<?php
$mysqli=new mysqli('localhost','root','','charity');
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

	$name 		= $request->name;
	$fname  	= $request->fname;
	$birth 		= $request->birth;
	$mobile  	= $request->mobile;
	$email  	= $request->email;
	$profesion  = $request->profesion;
	$blood  	= $request->blood;
	
	$query="insert into list set name='$name', father_name='$fname', birth_date='$birth', mobile='$mobile', email='$email', profesion='$profesion', blood_group='$blood'";
	$result=$mysqli->query($query);
	echo $query;
?>