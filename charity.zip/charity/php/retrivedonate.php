<?php
$mysqli=new mysqli('localhost','root','','charity');
$sql="select * from donation";
$query=$mysqli->query($sql);
$result=array();
while($rs=$query->fetch_object()){
	$result[]=$rs;
}
echo json_encode($result);
?>