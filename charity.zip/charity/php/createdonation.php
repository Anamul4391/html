<?php
$mysqli=new mysqli('localhost','root','','charity');
$postdata = file_get_contents("php://input");
$request = json_decode($postdata);

	$name 		= $request->name;
	$date 		= $request->date;
	$mobile  	= $request->mobile;
	$profesion  = $request->profesion;
	$amount  	= $request->amount;
	
	$query="insert into donation set name='$name', date='$date', mobile='$mobile', profesion='$profesion', payment='$amount'";
	$result=$mysqli->query($query);
	echo $query;
?>