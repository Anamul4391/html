<!DOCTYPE html>
<html lang="en">
<head>
  <title>Bootstrap Example</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/css/bootstrap.min.css">
  <script src="https://ajax.googleapis.com/ajax/libs/jquery/3.4.1/jquery.min.js"></script>
  <script src="https://cdnjs.cloudflare.com/ajax/libs/popper.js/1.16.0/umd/popper.min.js"></script>
  <script src="https://maxcdn.bootstrapcdn.com/bootstrap/4.4.1/js/bootstrap.min.js"></script>
</head>
<body>

<div class="container">
 <h3 align="center">Login in the form</h3>
  <form action="" method="post">
	
		  <div class="form-group">
			  <label class="control-label col-sm-2" for="email">Email:</label>
			  <div class="col-sm-10">
				<input type="email" class="form-control" id="email" placeholder="Enter your email" name="email">
			  </div>
		 </div>
		  <div class="form-group">
			  <label class="control-label col-sm-2" for="email">Password: </label>
			  <div class="col-sm-10">
				<input type="password" class="form-control" id="password" placeholder="Enter your password" name="password">
			  </div>
		 </div>
	
		 <div class="form-group">        
		  <div class="col-sm-offset-2 col-sm-10">
			<button type="submit" name="submit" class="btn btn-primary">Submit</button>
		  </div>
		</div>
    </form>
</div>

</body>
</html>

<?php
class database{
	public $connect;
	public function __construct(){
		$this->connect=new mysqli("localhost","root","","charity");
	}
	public function insert($q){
		$result=$this->connect->query($q);
		return $result;
	}
	
}
if(isset($_POST['submit'])){
	$db=new database;
	$email=$_POST['email'];
	$password=$_POST['password'];
	
	$query="insert into login set email='$email', password='$password'";
	$result=$db->insert($query);
	
}
?>
