<!DOCTYPE html>
<html lang="en">
<head>
  <title>Index form</title>
  <meta charset="utf-8">
  <meta name="viewport" content="width=device-width, initial-scale=1">
  <link rel="stylesheet" href="css/bootstrap.min.css">
  
</head>
<body>
	<div class="container">
		<div class="row">
			<div class="col-sm-3">
				<a class="btn btn-info" href="index.php">member</a>
			</div>
			<div class="col-sm-9">
				<h2>Member Information</h2>
				<hr/>
				<table border="1px">
					<tr>
						<td>Name</td>
						<td></td>
					</tr>
					<tr>
						<td>Father's Nmae</td>
						<td></td>
					</tr>
					<tr>
						<td>Birth date</td>
						<td></td>
					</tr>
					<tr>
						<td>Mobile</td>
						<td></td>
					</tr>
					<tr>
						<td>Email</td>
						<td></td>
					</tr>
					<tr>
						<td>Profesion</td>
						<td></td>
					</tr>
					<tr>
						<td>Blood Group</td>
						<td></td>
					</tr>
					<tr>
						<td>Comment</td>
						<td></td>
					</tr>
						
				</table>
			</div>
		</div>
	</div>
</body>
</html>