<!DOCTYPE html>
<html lang="en" ng-app="charity">
<head>
	<meta charset="utf-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1">

	<title>Welfare Society</title>

	<!-- Google font -->
	<link href="https://fonts.googleapis.com/css?family=Roboto:300,400%7CSource+Sans+Pro:700" rel="stylesheet">

	<!-- Bootstrap -->
	<link type="text/css" rel="stylesheet" href="css/bootstrap.min.css" />

	<!-- Owl Carousel -->
	<link type="text/css" rel="stylesheet" href="css/owl.carousel.css" />
	<link type="text/css" rel="stylesheet" href="css/owl.theme.default.css" />

	<!-- Font Awesome Icon -->
	<link rel="stylesheet" href="css/font-awesome.min.css">

	<!-- Custom stlylesheet -->
	<link type="text/css" rel="stylesheet" href="css/style.css" />

	<script src="ngmodules/angular.js"></script>
	<script>
		angular.module("charity", []);
		angular.module("charity")
		.controller("charityCtrl", function ($scope, $http) {
			/* this is for show user */
			$scope.data = {};
			$scope.datadonate = {};
			$scope.msg = '';
			
			$http.get('http://localhost/charity/php/retrive.php')
			.success(function (d) {
				$scope.data = d;
			})
			.error(function (error) {
				$scope.data.error = error;
			});
			
			$http.get('http://localhost/charity/php/retrivedonate.php')
			.success(function (d) {
				$scope.datadonate = d;
			})
			.error(function (error) {
				$scope.datadonate.error = error;
			});
		});
	</script>
</head>

<body ng-controller="charityCtrl">

	<header id="home">
		<!-- NAVGATION -->
		<nav id="main-navbar">
			<div class="container">
				<div class="navbar-header">
					<!-- Logo -->
					<div class="navbar-brand">
						<a class="logo" href="index.html"><img src="img/logo.png" alt="logo"></a>
					</div>
				<!-- Mobile toggle -->
					<button class="navbar-toggle-btn">
							<i class="fa fa-bars"></i>
						</button>
				
					<!-- Mobile Search toggle -->
					<button class="search-toggle-btn">
							<i class="fa fa-search"></i>
						</button>
				
				</div>

				<!-- Search -->
				<div class="navbar-search">
					<button class="search-btn"><i class="fa fa-search"></i></button>
					<div class="search-form">
						<form>
							<input class="input" type="text" name="search" placeholder="Search">
						</form>
					</div>
				</div>
				
				<!-- Nav menu -->
				<ul class="navbar-menu nav navbar-nav navbar-right">
					<li><a href="index.php">Home</a></li>
					<li><a href="donation.php">Donation-Contact</a></li>
					<li><a href="registration.php">Member Registration</a></li>
				</ul>
			
			</div>
		</nav>
	
		<!-- HOME part -->
		<div id="home-owl" class="owl-carousel owl-theme">
			<!-- HOME Subpart1 -->
			<div class="home-item">
				<div class="section-bg" style="background-image: url(./img/background-1.png);"></div>
				
				<div class="home">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<div class="home-content">
									<h1>Save The Poor</h1>
									<p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<a href="donation.php" class="primary-button">Donate</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
			
			<!-- HOME Subpart1 -->
			
			<div class="home-item">
				<div class="section-bg" style="background-image:url(./img/background-2.jpg);"></div>

				<div class="home">
					<div class="container">
						<div class="row">
							<div class="col-md-8">
								<div class="home-content">
									<h1>Become A Volunteer</h1>
									<p class="lead">Lorem ipsum dolor sit amet, consectetur adipisicing elit, sed do eiusmod tempor incididunt ut labore et dolore magna aliqua.</p>
									<a href="registration.php" class="primary-button">Join Us Now!</a>
								</div>
							</div>
						</div>
					</div>
				</div>
			</div>
		</div>
		<!-- /HOME part -->
	</header>
	<div class="container-fluid" style="padding-top:100px;background:#fff">
		<div class="row">
			<div class="col-md-12">
				<h1>List of Member</h1>
				<table class="table table-bordered">
					<thead>
						<th>#SL</th>
						<th>Name</th>
						<th>F.Name</th>
						<th>Birth Date</th>
						<th>Mobile</th>
						<th>Email</th>
						<th>Profesion</th>
						<th>Blood G.</th>
					</thead>
					<tbody>
						<tr ng-repeat="d in data">
							<td>{{ $index+1 }}</td>
							<td>{{ d.name }}</td>
							<td>{{ d.father_name }}</td>
							<td>{{ d.birth_date }}</td>
							<td>{{ d.mobile }}</td>
							<td>{{ d.email }}</td>
							<td>{{ d.profesion }}</td>
							<td>{{ d.blood_group }}</td>
						</tr>
					</tbody>
				</table>
			</div>
			<div class="col-md-12">
				<h1>List of Donation</h1>
				<table class="table table-bordered">
					<thead>
						<th>#SL</th>
						<th>Name</th>
						<th>Date</th>
						<th>Mobile</th>
						<th>Profesion</th>
						<th>Amount</th>
					</thead>
					<tbody>
						<tr ng-repeat="d in datadonate">
							<td>{{ $index+1 }}</td>
							<td>{{ d.name }}</td>
							<td>{{ d.date }}</td>
							<td>{{ d.mobile }}</td>
							<td>{{ d.profesion }}</td>
							<td>{{ d.payment }}</td>
						</tr>
					</tbody>
				</table>
			</div>
		</div>
	</div>


	<!-- jQuery Plugins -->
	<script src="js/jquery.min.js"></script>
	<script src="js/bootstrap.min.js"></script>
	<script src="js/owl.carousel.min.js"></script>
	<script src="js/jquery.stellar.min.js"></script>
	<script src="js/main.js"></script>

</body>

</html>
